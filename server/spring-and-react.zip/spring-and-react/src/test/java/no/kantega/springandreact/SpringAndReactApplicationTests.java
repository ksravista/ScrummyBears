package no.kantega.springandreact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAndReactApplicationTests {

	@Test
	void contextLoads() {
	}

}
